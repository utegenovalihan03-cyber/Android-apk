package com.example.myapplication   // ← обязательно оставь свой package (смотри первую строку)

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Подключаем XML-разметку
        setContentView(R.layout.activity_main)

        // Находим кнопку по ID
        val button: Button = findViewById(R.id.btnShowMessage)

        // При нажатии показываем Toast
        button.setOnClickListener {
            Toast.makeText(
                this,
                "Привет! Это мое первое приложение!",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}